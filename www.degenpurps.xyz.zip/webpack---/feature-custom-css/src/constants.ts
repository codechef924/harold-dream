export const customCssId = 'wix-custom-css'
export const pageId = 'masterPage'
export const CUSTOM_CSS_APP_ID = '081cfa21-cdf6-4f50-9a1b-0f3722acfd8b'
export const enum ViewEnvironment {
	PREVIEW = 'PREVIEW',
	EDITOR = 'EDITOR',
	PUBLIC = 'PUBLIC',
}
