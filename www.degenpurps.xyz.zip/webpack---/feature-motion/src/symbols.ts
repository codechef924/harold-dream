export const MotionSymbol = Symbol('Motion')
export const name = 'motion' as const
