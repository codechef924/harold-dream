export const name = 'siteWixCodeSdk' as const
export const namespace = 'site' as const
