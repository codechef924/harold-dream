const semanticClassNames = {
  root: 'repeater',
  repeaterItem: 'repeater__item',
} as const;

export default semanticClassNames;
