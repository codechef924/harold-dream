const semanticClassNames = {
  root: 'rich-text',
  text: 'rich-text__text',
} as const;

export default semanticClassNames;
