const semanticClassNames = {
  root: 'button',
  buttonLabel: 'button__label',
} as const;

export default semanticClassNames;
