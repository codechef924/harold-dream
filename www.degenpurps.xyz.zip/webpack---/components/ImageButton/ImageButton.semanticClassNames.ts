const semanticClassNames = {
  root: 'image-button',
} as const;

export default semanticClassNames;
