export const TestIds = {
  link: 'link',
} as const;
