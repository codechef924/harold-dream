export const name = 'wixCustomElementComponent' as const
export const WixCustomElementComponentAPISymbol = Symbol('WixCustomElementComponentAPISymbol')
export const WixCustomElementComponentEditorAPISymbol = Symbol('WixCustomElementComponentEditorAPISymbol')
