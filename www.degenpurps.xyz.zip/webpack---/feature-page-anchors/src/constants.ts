export const TOP_ANCHOR_COMP_ID = 'PAGE_TOP_ANCHOR'
export const TOP_ANCHOR_DATA_ID = 'SCROLL_TO_TOP'
export const TOP_ANCHOR = { compId: TOP_ANCHOR_COMP_ID, dataId: TOP_ANCHOR_DATA_ID }
export const WIX_ADS = 'WIX_ADS'
export const SCROLL_DEBOUNCE_WAIT = 100
export const RESIZE_DEBOUNCE_WAIT = 100
