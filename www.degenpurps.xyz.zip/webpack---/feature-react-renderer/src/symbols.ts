export const name = 'renderer' as const

export const STYLE_OVERRIDES_ID = 'STYLE_OVERRIDES_ID'
export const RendererPropsProviderSym = Symbol('RendererPropsProviderSym')
export const PageTransitionsHandlerSymbol = Symbol('PageTransitionsHandlerSymbol')
export const ThunderboltRootComponentRendererSym = Symbol('ThunderboltRootComponentRendererSymbol')
export const ComponentCssSym = Symbol('ComponentsCssSymbol')
